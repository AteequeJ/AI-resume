from django.contrib import admin
from .models import CandidateProfile

# Register your models here.
class CandidateProfileAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'created_at')