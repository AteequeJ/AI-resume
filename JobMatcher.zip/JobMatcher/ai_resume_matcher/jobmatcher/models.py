from django.db import models

# Create your models here.

class CandidateProfile(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    skills = models.JSONField()  # List of skills
    education = models.JSONField()  # List of education details
    work_experience = models.JSONField()  # List of work experience details
    resume_file = models.FileField(upload_to='resumes/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
    
    


class JobPosting(models.Model):
    title = models.CharField(max_length=255)
    company = models.CharField(max_length=255)
    location = models.CharField(max_length=255, blank=True, null=True)
    required_skills = models.JSONField()  # List of skills
    job_type = models.CharField(max_length=100, choices=[
        ('Full-time', 'Full-time'),
        ('Part-time', 'Part-time'),
        ('Contract', 'Contract'),
        ('Remote', 'Remote'),
    ])
    description = models.TextField()
    salary = models.CharField(max_length=50, blank=True, null=True)
    date_posted = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} at {self.company}"
    
    


class JobMatch(models.Model):
    candidate = models.ForeignKey("CandidateProfile", on_delete=models.CASCADE)
    job_posting = models.ForeignKey("JobPosting", on_delete=models.CASCADE)
    match_score = models.IntegerField()
    missing_skills = models.JSONField()
    summary = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.candidate.name} - {self.job_posting.title} ({self.match_score}%)"



class CoverLetter(models.Model):
    candidate = models.ForeignKey("CandidateProfile", on_delete=models.CASCADE)
    job_posting = models.ForeignKey("JobPosting", on_delete=models.CASCADE)
    cover_letter = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Cover Letter for {self.candidate.name} - {self.job_posting.title}"
