from django.urls import path
from .views import ResumeUploadView,JobPostingView,JobMatchView,CoverLetterView,get_candidates,get_jobs

urlpatterns = [
    path('upload-resume/', ResumeUploadView.as_view(), name='upload-resume'),
    path('job-postings/', JobPostingView.as_view(), name='job_posting'),
    path('match-candidate/', JobMatchView.as_view(), name='match_candidate'),
    path('generate-cover-letter/', CoverLetterView.as_view(), name='generate_cover_letter'),
    path('candidates/', get_candidates, name='candidates'),
    path('jobs/', get_jobs, name='candidates'),
]
