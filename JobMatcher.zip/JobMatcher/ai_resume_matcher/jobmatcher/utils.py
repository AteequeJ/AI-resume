import PyPDF2
import pdfplumber
import docx
import os

import json
import requests


def extract_text_from_resume(resume_file):
    """Extract text from a resume file (PDF or DOCX)."""
    _, file_extension = os.path.splitext(resume_file.name)
    
    if file_extension.lower() == ".pdf":
        text = ""
        with pdfplumber.open(resume_file) as pdf:
            for page in pdf.pages:
                text += page.extract_text() + "\n"
        return text.strip()

    elif file_extension.lower() in [".docx", ".doc"]:
        doc = docx.Document(resume_file)
        return "\n".join([para.text for para in doc.paragraphs])

    else:
        raise ValueError("Unsupported file format. Please upload a PDF or DOCX file.")




GENAI_API_KEY = "your_key"  # 🔹 Replace this with your actual key

GEMINI_API_KEY = "your_key"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

    
import json
import requests
import re

import json
import requests
import re

def parse_resume_with_llm(resume_text, debug=False):
    """
    Uses Google Gemini to extract structured data from a resume.
    """
    prompt = f"""
    Extract structured information from the following resume and return a valid JSON format.
    Ensure the response is **ONLY JSON** with no additional text.

    {resume_text}

    Include **ALL** of the following fields in the output, even if they are missing: 
    - Name
    - Email
    - Phone
    - **Skills**
    - Education
    - Work Experience

    Example JSON output:
    {{
        "name": "John Doe",
        "email": "johndoe@example.com",
        "phone": "+1234567890",
        "skills": ["Python", "Machine Learning", "Django"],
        "education": [
            {{"degree": "BSc Computer Science", "institution": "XYZ University", "year": "2020"}}
        ],
        "work_experience": [
            {{"role": "Software Engineer", "company": "Tech Corp", "years": "2020-2023"}}
        ]
    }}
    """

    try:
        response = requests.post(
            f"{GEMINI_API_URL}?key={GEMINI_API_KEY}",
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=15
        )

        # 🔹 Check API response
        if response.status_code != 200:
            return {"error": f"API request failed with status {response.status_code}: {response.text}"}

        # 🔹 Extract response JSON
        response_json = response.json()

        # 🔹 Debugging: Print full response if enabled
        if debug:
            print("🔹 Full Gemini API Response:", json.dumps(response_json, indent=4))

        # 🔹 Extract text content safely
        raw_text = response_json.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")

        # 🔹 Remove potential Markdown JSON formatting (` ```json ... ``` `) using regex
        clean_json_text = re.sub(r"```json|```", "", raw_text).strip()

        # 🔹 Convert to Python dictionary
        structured_data = json.loads(clean_json_text)

        # 🔹 Ensure required keys exist
        required_keys = ["name", "email", "phone", "skills", "education", "work_experience"]
        for key in required_keys:
            if key not in structured_data:
                structured_data[key] = [] if key in ["skills", "education", "work_experience"] else "N/A"

        # 🔹 Handle cases where Gemini returns "experience" instead of "work_experience"
        if "experience" in structured_data and "work_experience" not in structured_data:
            structured_data["work_experience"] = structured_data["experience"]
            del structured_data["experience"]

        # 🔹 Handle cases where Gemini returns "skillset" instead of "skills"
        if "skillset" in structured_data and "skills" not in structured_data:
            structured_data["skills"] = structured_data["skillset"]
            del structured_data["skillset"]

        return structured_data

    except requests.exceptions.RequestException as req_err:
        return {"error": f"Request failed: {str(req_err)}"}
    except json.JSONDecodeError:
        return {"error": "Failed to parse JSON response from Gemini"}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}




def parse_job_with_llm(job_text, debug=False):
    """
    Uses LLM (Google Gemini) to extract structured data from job descriptions.
    """
    prompt = f"""
    Extract structured job details from the following job posting and return JSON.

    {job_text}

    Example JSON:
    {{
        "title": "Software Engineer",
        "company": "Tech Corp",
        "location": "New York, NY",
        "required_skills": ["Python", "Django", "PostgreSQL"],
        "job_type": "Full-time",
        "description": "{job_text}",
        "salary": "$100,000 - $120,000 per year"
    }}
    """

    try:
        response = requests.post(
            f"{GEMINI_API_URL}?key={GEMINI_API_KEY}",
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=15
        )

        if response.status_code != 200:
            return {"error": f"API request failed: {response.status_code} - {response.text}"}

        response_json = response.json()
        raw_text = response_json.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")

        clean_json_text = raw_text.strip("```json").strip("```").strip()
        structured_data = json.loads(clean_json_text)

        if debug:
            print(json.dumps(structured_data, indent=4))

        return structured_data

    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}
    except json.JSONDecodeError:
        return {"error": "Failed to parse JSON response"}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}
    
    
    
    
def match_candidate_to_job(candidate_data, job_data, debug=False):
    """
    Uses LLM to compare a candidate's skills and experience with a job posting.
    Returns a match score, missing skills, and a summary.
    """
    prompt = f"""
    Compare the following candidate profile with the job posting and return structured JSON.

    Candidate Profile:
    {json.dumps(candidate_data, indent=2)}

    Job Posting:
    {json.dumps(job_data, indent=2)}

    Return JSON like this:
    {{
        "match_score": 85,
        "missing_skills": ["Docker", "Kubernetes"],
        "summary": "The candidate is a strong match but lacks experience with cloud technologies."
    }}
    """

    try:
        response = requests.post(
            f"{GEMINI_API_URL}?key={GEMINI_API_KEY}",
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=15
        )

        if response.status_code != 200:
            return {"error": f"API request failed: {response.status_code} - {response.text}"}

        response_json = response.json()
        raw_text = response_json.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")

        clean_json_text = raw_text.strip("```json").strip("```").strip()
        structured_data = json.loads(clean_json_text)

        if debug:
            print(json.dumps(structured_data, indent=4))

        return structured_data

    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}
    except json.JSONDecodeError:
        return {"error": "Failed to parse JSON response"}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}


def generate_cover_letter(candidate_data, job_data, custom_message=None, debug=False):
    """
    Uses LLM to generate a personalized cover letter for the candidate.
    """
    prompt = f"""
    Generate a professional cover letter for the following job application.

    Candidate Profile:
    {json.dumps(candidate_data, indent=2)}

    Job Posting:
    {json.dumps(job_data, indent=2)}

    Additional Notes from Candidate:
    {custom_message if custom_message else "N/A"}

    The cover letter should be formal, well-structured, and tailored to the job role.

    Return JSON like this:
    {{
        "cover_letter": "Dear Hiring Manager, ...\n\nSincerely, [Candidate Name]"
    }}
    """

    try:
        response = requests.post(
            f"{GEMINI_API_URL}?key={GEMINI_API_KEY}",
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=15
        )

        if response.status_code != 200:
            return {"error": f"API request failed: {response.status_code} - {response.text}"}

        response_json = response.json()
        raw_text = response_json.get("candidates", [{}])[0].get("content", {}).get("parts", [{}])[0].get("text", "")

        clean_json_text = raw_text.strip("```json").strip("```").strip()
        structured_data = json.loads(clean_json_text)

        if debug:
            print(json.dumps(structured_data, indent=4))

        return structured_data

    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}
    except json.JSONDecodeError:
        return {"error": "Failed to parse JSON response"}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}
