from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework import status
from .models import CandidateProfile,JobPosting,JobMatch,CoverLetter
from .serializers import CandidateProfileSerializer,JobPostingSerializer
from .utils import extract_text_from_resume, parse_resume_with_llm,parse_job_with_llm,match_candidate_to_job,generate_cover_letter
from django.http import JsonResponse

# Create your views here.
def get_candidates(request):
    candidates = CandidateProfile.objects.all().values()
    return JsonResponse(list(candidates), safe=False)

def get_jobs(request):
    jobs = JobPosting.objects.all().values()
    return JsonResponse(list(jobs), safe=False)

ALLOWED_EXTENSIONS = ["pdf", "docx", "txt"]
class ResumeUploadView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        """Handles resume upload, extracts text, and parses data using LLM."""
        resume_file = request.FILES.get('resume_file')

        if not resume_file:
            return Response({"error": "No file uploaded."}, status=status.HTTP_400_BAD_REQUEST)

        file_extension = resume_file.name.split(".")[-1].lower()
        if file_extension not in ALLOWED_EXTENSIONS:
            return Response({"error": "Invalid file type. Allowed: pdf, docx, txt"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Handle txt files separately
            if file_extension == "txt":
                extracted_text = resume_file.read().decode("utf-8")  # Read and decode text
            else:
                extracted_text = extract_text_from_resume(resume_file)  # Use existing extraction logic

            # Send the extracted text to the LLM for structured parsing
            parsed_data = parse_resume_with_llm(extracted_text)

            if not parsed_data:
                return Response({"error": "LLM failed to parse resume."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            # Save parsed data to database
            candidate = CandidateProfile.objects.create(
                name=parsed_data["name"],
                email=parsed_data["email"],
                phone=parsed_data.get("phone", ""),
                skills=parsed_data["skills"],
                education=parsed_data["education"],
                work_experience=parsed_data["work_experience"],
                resume_file=resume_file
            )

            serializer = CandidateProfileSerializer(candidate)
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        
        
class JobPostingView(APIView):
    def post(self, request):
        job_text = request.data.get("job_description", "")

        if not job_text:
            return Response({"error": "Job description is required"}, status=status.HTTP_400_BAD_REQUEST)

        parsed_data = parse_job_with_llm(job_text)

        if "error" in parsed_data:
            return Response(parsed_data, status=status.HTTP_400_BAD_REQUEST)

        job_posting = JobPosting.objects.create(**parsed_data)
        serializer = JobPostingSerializer(job_posting)
        
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    
    
class JobMatchView(APIView):
    def post(self, request):
        candidate_id = request.data.get("candidate_id")
        job_id = request.data.get("job_id")

        if not candidate_id or not job_id:
            return Response({"error": "Both candidate_id and job_id are required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            candidate = CandidateProfile.objects.get(id=candidate_id)
            job = JobPosting.objects.get(id=job_id)
        except CandidateProfile.DoesNotExist:
            return Response({"error": "Candidate not found"}, status=status.HTTP_404_NOT_FOUND)
        except JobPosting.DoesNotExist:
            return Response({"error": "Job posting not found"}, status=status.HTTP_404_NOT_FOUND)

        match_result = match_candidate_to_job(
            candidate_data={
                "name": candidate.name,
                "skills": candidate.skills,
                "education": candidate.education,
                "work_experience": candidate.work_experience
            },
            job_data={
                "title": job.title,
                "company": job.company,
                "required_skills": job.required_skills,
                "description": job.description
            }
        )

        if "error" in match_result:
            return Response(match_result, status=status.HTTP_400_BAD_REQUEST)

        match = JobMatch.objects.create(
            candidate=candidate,
            job_posting=job,
            match_score=match_result["match_score"],
            missing_skills=match_result["missing_skills"],
            summary=match_result["summary"]
        )

        return Response({
            "candidate": candidate.name,
            "job_title": job.title,
            "match_score": match.match_score,
            "missing_skills": match.missing_skills,
            "summary": match.summary
        }, status=status.HTTP_201_CREATED)




class CoverLetterView(APIView):
    def post(self, request):
        candidate_id = request.data.get("candidate_id")
        job_id = request.data.get("job_id")
        custom_message = request.data.get("custom_message", "")

        if not candidate_id or not job_id:
            return Response({"error": "Both candidate_id and job_id are required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            candidate = CandidateProfile.objects.get(id=candidate_id)
            job = JobPosting.objects.get(id=job_id)
        except CandidateProfile.DoesNotExist:
            return Response({"error": "Candidate not found"}, status=status.HTTP_404_NOT_FOUND)
        except JobPosting.DoesNotExist:
            return Response({"error": "Job posting not found"}, status=status.HTTP_404_NOT_FOUND)

        cover_letter_result = generate_cover_letter(
            candidate_data={
                "name": candidate.name,
                "skills": candidate.skills,
                "education": candidate.education,
                "work_experience": candidate.work_experience
            },
            job_data={
                "title": job.title,
                "company": job.company,
                "required_skills": job.required_skills,
                "description": job.description
            },
            custom_message=custom_message
        )

        if "error" in cover_letter_result:
            return Response(cover_letter_result, status=status.HTTP_400_BAD_REQUEST)

        cover_letter = CoverLetter.objects.create(
            candidate=candidate,
            job_posting=job,
            cover_letter=cover_letter_result["cover_letter"]
        )

        return Response({
            "candidate": candidate.name,
            "job_title": job.title,
            "cover_letter": cover_letter.cover_letter
        }, status=status.HTTP_201_CREATED)
