import streamlit as st
import requests

API_BASE_URL = "http://127.0.0.1:8000/api"

# Custom styles
st.markdown(
    """
    <style>
        .stTitle { text-align: center; color: #4CAF50; }
        .stHeader { color: #2E86C1; }
        .stButton { text-align: center; }
        .stWarning { color: #D9534F; }
    </style>
    """,
    unsafe_allow_html=True,
)

# Sidebar
st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Home", "Upload Resume", "Match Candidates", "Generate Cover Letter"])

st.title("🤖 AI Resume & Job Matcher")
st.markdown("---")

if page == "Upload Resume":
    st.header("📄 Upload Resume")
    uploaded_file = st.file_uploader("Upload a PDF, DOCX, or TXT resume", type=["pdf", "docx", "txt"])
    if uploaded_file:
        st.success(f"Uploaded: {uploaded_file.name}")
        files = {"resume_file": (uploaded_file.name, uploaded_file.getvalue(), uploaded_file.type)}
        response = requests.post(f"{API_BASE_URL}/upload-resume/", files=files)
        try:
            response_json = response.json()
            if response.status_code == 201 and "id" in response_json:
                st.success("✅ Resume uploaded & parsed successfully!")
                st.json(response_json)
            else:
                st.error(f"Unexpected response: {response_json}")
        except ValueError:
            st.error(f"Failed to process resume. Server Response: {response.text}")

elif page == "Match Candidates":
    st.header("🔍 Match Candidates to Jobs")
    
    st.subheader("Select a Candidate")
    candidates_response = requests.get(f"{API_BASE_URL}/candidates/")
    selected_candidate = None
    if candidates_response.status_code == 200:
        candidates = candidates_response.json()
        if candidates:
            selected_candidate = st.selectbox("Choose a candidate:", candidates, format_func=lambda c: f"{c['name']} - {c['email']}")
        else:
            st.warning("No candidates found. Please upload a resume first.")
    else:
        st.error("Error fetching candidates.")
    
    st.subheader("Select a Job")
    jobs_response = requests.get(f"{API_BASE_URL}/jobs/")
    selected_job = None
    if jobs_response.status_code == 200:
        jobs = jobs_response.json()
        if jobs:
            selected_job = st.selectbox("Choose a job:", jobs, format_func=lambda j: f"{j['title']} - {j['company']}")
        else:
            st.warning("No jobs found. Please add jobs first.")
    else:
        st.error("Error fetching jobs.")
    
    if st.button("Match Candidate to Job", key="match_button"):
        if selected_candidate and selected_job:
            match_response = requests.post(
                f"{API_BASE_URL}/match-candidate/",
                json={"candidate_id": selected_candidate["id"], "job_id": selected_job["id"]}
            )
            if match_response.status_code in [200, 201]:
                try:
                    match_result = match_response.json()
                    st.subheader(f"✅ Match Result for {match_result.get('candidate', 'Unknown')} & {match_result.get('job_title', 'Unknown')}")
                    st.write(f"**Match Score:** {match_result.get('match_score', 'N/A')}%")
                    st.write(f"**Missing Skills:** {', '.join(match_result.get('missing_skills', [])) if match_result.get('missing_skills') else 'None'}")
                    st.write(f"**Summary:** {match_result.get('summary', 'No summary available.')}")
                except ValueError:
                    st.error("⚠️ Failed to parse JSON response.")
            else:
                st.error(f"❌ Match failed! Server Response: {match_response.text}")
        else:
            st.warning("Please select a candidate and a job.")

elif page == "Generate Cover Letter":
    st.header("✉️ Generate Cover Letter")
    
    st.subheader("Select a Candidate")
    candidates_response = requests.get(f"{API_BASE_URL}/candidates/")
    selected_candidate = None
    if candidates_response.status_code == 200:
        candidates = candidates_response.json()
        if candidates:
            selected_candidate = st.selectbox("Choose a candidate:", candidates, format_func=lambda c: f"{c['name']} - {c['email']}", key="cover_candidate")
        else:
            st.warning("No candidates found. Please upload a resume first.")
    else:
        st.error("Error fetching candidates.")
    
    st.subheader("Select a Job")
    jobs_response = requests.get(f"{API_BASE_URL}/jobs/")
    selected_job = None
    if jobs_response.status_code == 200:
        jobs = jobs_response.json()
        if jobs:
            selected_job = st.selectbox("Choose a job:", jobs, format_func=lambda j: f"{j['title']} - {j['company']}", key="cover_job")
        else:
            st.warning("No jobs found. Please add jobs first.")
    else:
        st.error("Error fetching jobs.")
    
    custom_message = st.text_area("Add a Custom Message (Optional)", "")
    if st.button("Generate Cover Letter", key="cover_button"):
        if selected_candidate and selected_job:
            cover_response = requests.post(
                f"{API_BASE_URL}/generate-cover-letter/",
                json={"candidate_id": selected_candidate["id"], "job_id": selected_job["id"], "custom_message": custom_message}
            )
            if cover_response.status_code in [200, 201]:
                st.subheader("Generated Cover Letter:")
                st.text_area("Cover Letter", cover_response.json()["cover_letter"], height=200)
            else:
                st.error("Failed to generate cover letter.")
        else:
            st.warning("Please select a candidate and a job.")
